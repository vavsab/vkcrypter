var Constants = {
	marker: "AESSTART"
};