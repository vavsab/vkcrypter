# VkCrypter

Chrome extension that encrypts chat messages on vk.com using AES algorithm.

Inspired by:

http://coderaiser.github.io/vkcrypt/

https://sourceforge.net/projects/vkcrypt/

https://crypter.co.uk/
